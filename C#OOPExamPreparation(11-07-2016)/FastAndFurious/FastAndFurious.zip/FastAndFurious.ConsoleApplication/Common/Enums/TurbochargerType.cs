﻿namespace FastAndFurious.ConsoleApplication.Common.Enums
{
    public enum TurbochargerType
    {
        NotSet = 0,
        SequentialTurbo,
        TwinTurbo
    }
}
