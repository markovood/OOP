﻿namespace Dealership.Contracts
{
    public interface ITruck
    {
        int WeightCapacity { get; }
    }
}
